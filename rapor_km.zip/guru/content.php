<?php  
        $pages = $_GET['pages'];
        if ($pages == "") {
        	include "dashboard.php";
        }
        if ($pages == "kelas-ku") {
        	include "kelas-ku.php";
        }        
        
        if ($pages == "tujuan-pembelajaran") {
        	include "tujuan-pembelajaran.php";
        }
        if ($pages == "penilaian") {
        	include "penilaian.php";
        }
        if ($pages == "lager-nilai-kelas") {
        	include "lager-nilai-kelas.php";
        }
        if ($pages == "catatan-rapor") {
        	include "catatan-rapor.php";
        }
        
        if ($pages == "project-kelas") {
        	include "project-kelas.php";
        }
        
        if ($pages == "detail-project") {
        	include "detail-project.php";
        }
        
        if ($pages == "penilaian-profil-pancasila") {
        	include "penilaian-profil-pancasila.php";
        }
        
        
        if ($pages == "pembelajaran-kelas") {
        	include "pembelajaran-kelas.php";
        }
        if ($pages == "anggota-kelas") {
        	include "anggota-kelas.php";
        }
        if ($pages == "ekstra") {
        	include "ekstra.php";
        }
        if ($pages == "prakerin") {
        	include "prakerin.php";
        }
        if ($pages == "buku-induk") {
        	include "buku-induk.php";
        }
        if ($pages == "piket-harian") {
        	include "piket-harian.php";
        }
        
        if ($pages == "rekap-presensi") {
        	include "rekap-presensi.php";
        }
        if ($pages == "tpu") {
        	include "tujuan-pembelajaran_umum.php";
        }
        if ($pages == "deskripsi-rapor") {
        	include "deskripsi-rapor.php";
        }
        
        if ($pages == "absensi-bk") {
        	include "absensi-bk.php";
        }
        

        ?>