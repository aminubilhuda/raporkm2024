<footer class="footer">
    © 2024 SMK Abdi Negara Tuban. All rights reserved.

</footer>