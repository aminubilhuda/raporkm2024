<!-- $stmt = $mysqli->prepare("SELECT kontak FROM users JOIN kelas_wali ON users.id_user=kelas_wali.id_user WHERE id_kelas = ?"); -->

<?php

// Impor token dari file apikey.php
include 'apikey.php'; // Pastikan path-nya sesuai dengan lokasi file apikey.php

function kirimPesanBroadcast($nomorTujuan, $pesan) {
    global $token; // Ambil token dari variabel global yang diimpor dari apikey.php

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.fonnte.com/send',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'target' => implode(',', $nomorTujuan),
            'message' => $pesan,
            'countryCode' => '62', // optional, default Indonesia
        ),
        CURLOPT_HTTPHEADER => array(
            "Authorization: $token"
        ),
    ));

    $response = curl_exec($curl);

    // if (curl_errno($curl)) {
    //     echo 'Curl error: ' . curl_error($curl);
    // } else {
    //     echo 'Response: ' . $response;
    // }

    // curl_close($curl);
    return $response;
}
function kirimPesanWali($nomorTujuan, $pesan) {
    global $token; // Ambil token dari variabel global yang diimpor dari apikey.php

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.fonnte.com/send',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'target' => $nomorTujuan,
            'message' => $pesan,
            'countryCode' => '62', // optional, default Indonesia
        ),
        CURLOPT_HTTPHEADER => array(
            "Authorization: $token"
        ),
    ));

    $response = curl_exec($curl);

    // if (curl_errno($curl)) {
    //     echo 'Curl error: ' . curl_error($curl);
    // } else {
    //     echo 'Response: ' . $response;
    // }

    // curl_close($curl);
    return $response;
}

function getKontakWaliKelas($id_kelas) {
    global $mysqli;
    $stmt = $mysqli->prepare("SELECT kontak FROM users JOIN kelas_wali ON users.id_user=kelas_wali.id_user WHERE id_kelas = ?");
    $stmt->bind_param("s", $id_kelas);
    $stmt->execute();
    $result = $stmt->get_result();
    $kontakWaliKelas = $result->fetch_array();
    return $kontakWaliKelas['kontak'];
}

function tampilkanNotifikasi($responseJson) {
    // Jika response kosong atau null, tidak menampilkan apa-apa
    if (empty($responseJson)) {
        return;
    }

    // Decode JSON response menjadi array asosiatif
    $response = json_decode($responseJson, true);

    if (!$response || !isset($response['status']) || !$response['status']) {
        echo '<div class="alert alert-danger">Gagal memproses permintaan.</div>';
        return;
    }

    // Ambil data yang diperlukan dari response
    $message = $response['detail'];
    $processStatus = $response['process'];
    $ids = $response['id'];
    $targets = $response['target'];

    // Inisialisasi array untuk pesan berhasil dan gagal
    $successMessages = [];
    $failedMessages = [];

    // Buat notifikasi untuk setiap target
    foreach ($targets as $index => $target) {
        // Contoh logika untuk memisahkan berhasil dan gagal
        // Di sini saya asumsikan pesan dianggap berhasil jika prosesnya "processing"
        // Anda dapat menyesuaikan logika ini sesuai dengan kriteria yang diberikan API
        if ($processStatus === 'processing') {
            $successMessages[] = "Nomor: $target - ID: {$ids[$index]} berhasil dikirim.";
        } else {
            $failedMessages[] = "Nomor: $target - ID: {$ids[$index]} gagal dikirim.";
        }
    }

    // Tampilkan notifikasi sukses
    if (!empty($successMessages)) {
        echo '<div class="alert alert-success">';
        echo "<strong>Pesan Berhasil Dikirim:</strong><br>";
        echo '<ul>';
        foreach ($successMessages as $successMessage) {
            echo "<li>$successMessage</li>";
        }
        echo '</ul>';
        echo '</div>';
    }

    // Tampilkan notifikasi gagal
    if (!empty($failedMessages)) {
        echo '<div class="alert alert-danger">';
        echo "<strong>Pesan Gagal Dikirim:</strong><br>";
        echo '<ul>';
        foreach ($failedMessages as $failedMessage) {
            echo "<li>$failedMessage</li>";
        }
        echo '</ul>';
        echo '</div>';
    }
}


?>