<script>
alert("Dilarang Mengakses secara langsung");
window.location.href = "../../index.php";
</script>
```
</rewritten_file>
<|eot_id|>