<?php

$token = 'ZCsbkaSEMfhW9v8AaePt'; // Ganti dengan token sebenarnya