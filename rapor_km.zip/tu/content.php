<?php  
        $pages = $_GET['pages'];
        if ($pages == "") {
        	include "dashboard.php";
        }
        if ($pages == "profil") {
        	include "sekolah.php";
        }
        if ($pages == "pegawai") {
        	include "pegawai.php";
        }
        if ($pages == "kesiswaan") {
        	include "kesiswaan.php";
        }
        if ($pages == "rombel") {
        	include "rombel.php";
        }
        if ($pages == "mapel") {
        	include "mapel.php";
        }
        if ($pages == "ekstra") {
        	include "ekstra.php";
        }
        if ($pages == "prestasi-siswa") {
          include "prestasi-siswa.php";
        }
        if ($pages == "mapel-siswa") {
          include "mapel-siswa.php";
        }
        if ($pages == "anggota-kelas") {
        	include "anggota-kelas.php";
        }
        if ($pages == "mapel-kelas") {
        	include "mapel-kelas.php";
        }

        if ($pages == "ppra") {
        	include "ppra.php";
        }

        if ($pages == "pengingat") {
          include "pengingat.php";
        }
        if ($pages == "laporan_wa") {
          include "laporan_wa.php";
        }
        
        if ($pages == "pengaturan") {
          include "pengaturan.php";
        }

        if ($pages == "mutasi-masuk") {
          include "mutasi-masuk.php";
        }
        if ($pages == "mutasi-keluar") {
          include "mutasi-keluar.php";
        }
        if ($pages == "lulusan") {
          include "lulusan.php";
        }

        if ($pages == "nilai-akademik") {
          include "nilai-akademik.php";
        }

        if ($pages == "voting-osis") {
          include "voting-osis.php";
        }

        if ($pages == "detail-voting") {
          include "detail-voting.php";
        }
        if ($pages == "rekrutmen") {
          include "rekrutmen.php";
        }
        if ($pages == "detail-rekrutmen") {
          include "detail-rekrutmen.php";
        }

        if ($pages == "assesmen-akhir") {
          include "assesmen-akhir.php";
        }
        
        if ($pages == "kompetensi") {
          include "kompetensi-keahlian.php";
        }
        
        if ($pages == "pemberitaan") {
          include "pemberitaan.php";
        }
        
        if ($pages == "program-aplikasi") {
          include "program-aplikasi.php";
        }
        
        if ($pages == "angket-survey") {
          include "angket-survey.php";
        }
        
        if ($pages == "supervisi") {
          include "supervisi.php";
        }
        
        if ($pages == "prakerin") {
          include "prakerin.php";
        }
        
        if ($pages == "akademik") {
          include "akademik.php";
        }
        if ($pages == "laporan-pendidikan") {
          include "laporan-pendidikan.php";
        }
        
        if ($pages == "buku-induk") {
          include "buku-induk.php";
        }
        
        if ($pages == "prestasi") {
          include "prestasi.php";
        }
        
        if ($pages == "piket-harian") {
          include "piket-harian.php";
        }
        
        if ($pages == "rekap-presensi") {
          include "rekap-presensi.php";
        }
        if ($pages == "kesiswaan-upload") {
          include "kesiswaan-upload.php";
        }
        if ($pages == "deskripsi-rapor") {
          include "deskripsi-rapor.php";
        }

        ?>